## Installation Steps (安装步骤)

cd py_install

sudo python3 setup.py install