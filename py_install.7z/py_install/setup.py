from setuptools import find_packages, setup

setup(
    name='Raspbot_Lib',
    version='0.0.2',
    py_modules = ['Raspbot_Lib'],
    author='Yahboom Team',
    url='www.yahboom.com',
    packages=find_packages(),
    description='Raspbot drvier V0.0.2'
)